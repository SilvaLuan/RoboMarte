﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robo.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Declaração de variaveis do Robo 1 e Robo 2*/
            String orientacoes1, comandos1, saida1, orientacoes2, comandos2,saida2;
            double posicaoX1, posicaoY1, posicaoX2, posicaoY2;

            while (true){

                /*Robo 1*/
                Console.WriteLine("Digite a Posição x do Robo 1 (As posições disponíveis são 0 e 1 se digitar 2 a aplicação fecha):");
                posicaoX1 = Convert.ToDouble(Console.ReadLine());
                
                if (posicaoX1==2)/*Se digitar 2 na hora de inserir a posição x do robo 1 fecha aplicação*/
                {
                   break;
                }

                Console.WriteLine("Digite a Posição y do Robo 1:");
                posicaoY1 = Convert.ToDouble(Console.ReadLine());
                
                Console.WriteLine("Digite a orientação do Robo 1 (n = norte, s = sul, l = leste, o = oeste):");
                orientacoes1 = Console.ReadLine();

                Console.WriteLine("Digite os comandos pro robo 1 (e, d ou m):");
                comandos1 = Console.ReadLine();
                
                /*Robo 2*/
                Console.WriteLine("Digite a Posição x do Robo 2 (As posições disponíveis são 0 e 1 se digitar 2 a aplicação fecha):");
                posicaoX2 = Convert.ToDouble(Console.ReadLine());

                if (posicaoX2 == 2)/*Se digitar 2 na hora de inserir a posição x do robo 2 fecha aplicação*/
                {
                    break;
                }

                Console.WriteLine("Digite a Posição y do Robo 2:");/*imprime o enunciado*/
                posicaoY2 = Convert.ToDouble(Console.ReadLine());/*converte string para double e le as informações inseridas*/

                Console.WriteLine("Digite a orientação do Robo 2 (n = norte, s = sul, l = leste, o = oeste):");/*imprime o enunciado*/
                orientacoes2 = Console.ReadLine();/*le as informações inseridas*/

                Console.WriteLine("Digite os comandos pro robo 2 (e, d ou m):");/*Imprime o enunciado*/
                comandos2 = Console.ReadLine();/*le as informações inseridas*/

                saida1 = posicaoX1 + posicaoY1 + orientacoes1 + comandos1;

                saida2 = posicaoX2 + posicaoY2 + orientacoes2 + comandos2;

                Console.WriteLine(saida1);/*imprime as informações do robo 1*/
                Console.WriteLine(saida2);/*imprime as informações do robo 2*/
                Console.ReadLine();
                Console.Clear();
                continue;
              
            }
        }
    }
}
